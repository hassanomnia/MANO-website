package web.shopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataBaseManagement {
    
    static final String url = "jdbc:postgresql:shopping";
    static final String user = "postgres";
    static final String password = "01118414865";
    static Connection connection;
    static PreparedStatement preparedStatment = null;
    static ResultSet result = null;
    static String sqlCommand;
    static String sqlCommand1;
    static char[] ch = null;
    static Statement state;
    static String nme = "";
    static boolean checkname = true;

    static void connect() {
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(url, user, password);
            state = connection.createStatement();
            System.err.println("Connection is made successfully");
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataBaseManagement.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    static void close() {
        try {
            connection.close();
            System.err.println("Connection is closed successfully");
        } 
        catch (SQLException ex) {
            Logger.getLogger(DataBaseManagement.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    static ResultSet selectAllProducts() {
        try {
            state =connection.createStatement();
            sqlCommand = "SELECT * from product ";
            result = state.executeQuery(DataBaseManagement.sqlCommand);
        } 
        catch (SQLException ex) {
            Logger.getLogger(DataBaseManagement.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
   
    
    
}
