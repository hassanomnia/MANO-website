package web.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchPage extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        String part1 = "  \n"
                + "    <div class=\"product-big-title-area\">\n"
                + "        <div class=\"container\">\n"
                + "            <div class=\"row\">\n"
                + "                <div class=\"col-md-12\">\n"
                + "                    <div class=\"product-bit-title text-center\">\n"
                + "                        <h2>Search</h2>\n"
                + "                    </div>\n"
                + "                </div>\n"
                + "            </div>\n"
                + "        </div>\n"
                + "    </div>\n"
                + "    \n"
                + "    \n";
        String part2 = "<div class=\"single-product-area\">\n"
                + "        <div class=\"zigzag-bottom\"></div>\n"
                + "        <div class=\"container\">\n"
                + "            <div class=\"row\">\n"
                + "                <div class=\"col-md-4\">\n"
                + "                    <div class=\"single-sidebar\">\n"
                + "                        <h2 class=\"sidebar-title\">Search Products</h2>\n"
                + "                        <form action=\"#\">\n"
                + " <input type=\"radio\" id=\"box1\" name=\"search\" onclick = \"getAnswer('c') value=\"category\">\n"
                + "  <label>by Category</label><br>\n"
                + "  <input type=\"radio\" id=\"box2\" name=\"search\" onclick = \"getAnswer('p') value=\"price\">\n"
                + "  <label>by Price</label><br>"
                + "</select>"
                + "                            <input type=\"text\" placeholder=\"Search products...\">\n"
                + "                            <input type=\"submit\" value=\"Search\">\n"
                + "                        </form>\n"
                + "                    </div>\n";
               

        String radio = request.getParameter("search");
        ResultSet result =DataBaseManagement.selectAllProducts();
       

        RequestDispatcher dispatcherHeader = request.getRequestDispatcher("/header.html");
        dispatcherHeader.include(request, response);

        out.println(part1);
        out.println(part2);
         if (radio != null) {
            if(radio.equals("category"))
            {
              out.println("<p>v</p>");
            }
            if(radio.equals("p"))
            {
                out.println("<p>jgkd</p>");
            }
        } else {
            System.out.println("no radio button was selected");
        }
//        RequestDispatcher dispatcherFooter = request.getRequestDispatcher("/footer.html");
//        dispatcherFooter.include(request, response);
    }
}
