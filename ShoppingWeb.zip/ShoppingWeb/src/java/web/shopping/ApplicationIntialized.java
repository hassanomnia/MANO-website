
package web.shopping;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ApplicationIntialized implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        DataBaseManagement.connect();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
       DataBaseManagement.close();
    }
}
