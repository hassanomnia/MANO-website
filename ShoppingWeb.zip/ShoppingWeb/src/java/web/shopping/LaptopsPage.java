
package web.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LaptopsPage extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
            PrintWriter out = response.getWriter();
            String laptops_description ;
            RequestDispatcher dispatcherHeader = request.getRequestDispatcher("/header.html");
            dispatcherHeader.include(request, response);
            try {
            ResultSet result =DataBaseManagement.selectAllProducts();
            String startDiv ="    <div class=\"product-big-title-area\">\n" +
"        <div class=\"container\">\n" +
"            <div class=\"row\">\n" +
"                <div class=\"col-md-12\">\n" +
"                    <div class=\"product-bit-title text-center\">\n" +
"                        <h2>Laptops</h2>\n" +
"                    </div>\n" +
"                </div>\n" +
"            </div>\n" +
"        </div>\n" +
"    </div>";
            String space =" <div class=\"single-product-area\">\n" +
"        <div class=\"zigzag-bottom\"></div>\n" +
"        <div class=\"container\">\n" +
"            <div class=\"row\">";
            response.setContentType("text/html");
            out.println(startDiv);
            out.println(space);
            while (result.next()) {
             if(result.getString(3).equals("laoptop")){
                String imag =result.getString(8);
                String description =result.getString(6);
                String price =result.getString(2);
                String quantity = result.getString(7);
                laptops_description=
                    "                <div class=\"col-md-3 col-sm-6\">\n" +
                    "                    <div class=\"single-shop-product\">\n" +
                    "                        <div class=\"product-upper\">\n" +
                    "                        <img src=\""+imag+"\" alt=\"\">\n" +  //import image
                    "                        </div>\n" +
                    "                        <h2><a href=\"\">"+description+"</a></h2>\n" +   // import description
                    "                        <div class=\"product-carousel-price\">\n" +
                    "                            <ins>$"+price+"</ins> <del>$999.00</del>\n" +         //import price
                    "                        </div>  \n" +
                    "                        \n" +
                    "                        <div class=\"product-option-shop\">\n" +
                    "                            <a class=\"add_to_cart_button\" data-quantity=\""+quantity+"\" data-product_sku=\"\" data-product_id=\"70\" rel=\"nofollow\" href=\"/canvas/shop/?add-to-cart=70\">Add to cart</a>\n" +
                    "                        </div>                       \n" +
                    "                    </div>\n" +
                    "                </div>\n" ;
                    out.println(laptops_description);
             }
            }
            String closeDiv ="  </div>\n" +
"                </div>\n" +
"            </div>\n" +
"        </div>\n" +
"    </div>";
            out.println(closeDiv);
        } 
        catch (SQLException ex) {
            Logger.getLogger(LaptopsPage.class.getName()).log(Level.SEVERE, null, ex);
        }       
//        RequestDispatcher dispatcherFooter = request.getRequestDispatcher("/footer.html");
//        dispatcherFooter.include(request, response);
        
    }

    

}
